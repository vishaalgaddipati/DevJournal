### Link to Miro board

https://miro.com/app/board/uXjVKMiOIZM=/
