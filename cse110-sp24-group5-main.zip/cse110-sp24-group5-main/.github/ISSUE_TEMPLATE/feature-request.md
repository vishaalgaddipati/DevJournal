---
name: Feature Request
about: Creation of new page + adding features to existing ones
title: ''
labels: ''
assignees: ''

---

# Feature Request

## Summary
[Summarize the feature or improvement you are proposing.]

## Details
[Provide detailed information about the feature, including how it should work and any specific requirements or considerations.]

## Important Considerations
[Highlight any important considerations or potential impacts of implementing this feature.]

[Link to additional information, if available.]
