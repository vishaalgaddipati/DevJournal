//test
describe('Math', () => {
    it('should add 1 + 1 to equal 2', () => {
      expect(1 + 1).toBe(2);
    });
});
  