[YouTube link for MVP video](https://www.youtube.com/watch?v=myacnpHmjUQ)
