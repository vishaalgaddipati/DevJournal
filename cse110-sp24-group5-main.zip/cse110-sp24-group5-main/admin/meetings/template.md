
# Meeting Minutes

## Meeting Information
**Team Number and Name:**
**Type of Meeting:**
**Meeting Date and Location:** 
**Meeting Purpose:** 


## Attendees
People who attended:
- Person A
- Person B
- Person C

## Agenda Items

#### Unresolved from previous meeting

TODO

#### Things to be discussed

TODO

#### Unresolved from this meeting

TODO

## Decisions made and Reasoning



## Action Items
| Done? | Task | People | Due Date |
| ---- | ---- | ---- | ---- |
| | item | who | due_date |

## Other Notes & Information
