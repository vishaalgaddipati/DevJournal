
# Meeting Minutes

## Meeting Information
**Team Number and Name: Panda Coding Express, Team 5**

**Type of Meeting: Meeting for a group project** 

**Meeting Date and Location: 04/23/2024, Catalyst** 

**Meeting Purpose:** 


## Attendees
People who attended:
- Mishka
- Vishaal

## Agenda Items

#### Unresolved from previous meeting
N/A

#### Things to be discussed
How to develop the basic structure in HTML for the warmup assignment

#### Unresolved from this meeting
- Adding documentation and meeting notes

## Decisions made and Reasoning



## Action Items
| Done? | Task                              | People           | Due Date      |
|-------|-----------------------------------|------------------|---------------|
| yes   | adding the calendar component    | Mishka, Vishaal  | Wednesday 10 am |
| yes   | adding the task component        | Mishka, Vishaal  | Wednesday 10 am |
| yes    | adding comments and documentation| Drishti          | Wednesday 10 am |
        



## Other Notes & Information
