
# Meeting Minutes

## Meeting Information
**Team Number and Name:**
**Type of Meeting:**
**Meeting Date and Location:** 
**Meeting Purpose:** 


## Attendees
People who attended:
- Arnav
- Drishti
- Mishka
- Vishaal

## Agenda Items

Discuss ideas for keyboard shortcuts feature

#### Unresolved from previous meeting

NA

#### Things to be discussed

NA

#### Unresolved from this meeting

NA

## Decisions made and Reasoning



## Action Items

NA

## Other Notes & Information

NA